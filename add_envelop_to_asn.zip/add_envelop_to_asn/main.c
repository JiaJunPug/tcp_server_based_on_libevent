/*
 * main.c
 *
 *  Created on: Nov 14, 2019
 *      Author: root
 */
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <wait.h>
#include <errno.h>
#include <netdb.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <sys/time.h>
#include <stdint.h>
//#include <util.h>


#include "SVSRequest.h"
#include "SVSRespond.h"


//=======================================================================
//
int svsdata_test()
{
	SVSRequest_t *req_enc = NULL;
	SVSRequest_t *req_dec = NULL;
	SVSRespond_t *res_enc = NULL;

	time_t now;
	struct tm *cur_tm;
	unsigned char buf[4096];
	int len = 4096;
	FILE *pf = NULL;

	asn_enc_rval_t ec;
	asn_dec_rval_t rval;

	int err = 0;

	req_enc = (SVSRequest_t*)calloc(1, sizeof(SVSRequest_t));
	if (!req_enc) {
		perror("calloc failed");
		exit(1);
	}

	req_enc->version = 0;
	req_enc->reqType = ReqType_exportCert;

	req_enc->request.present = Request_PR_exportCertReq;
	if ((err = OCTET_STRING_fromBuf(&req_enc->request.choice.exportCertReq.identification, "123456", 6)) != 0) {

		fprintf(stderr, "OCTET_STRING_fromString() failed, return: %d\n", err);
        exit(2);
	}

	now = time(NULL);
	cur_tm = localtime(&now);
	asn_time2GT(&req_enc->reqTime, cur_tm, 1);

	ec = der_encode_to_buffer(&asn_DEF_SVSRequest, req_enc, buf, len);
    if(ec.encoded  == -1) {

        fprintf(stderr, "Could not encode SVSRequest (at %s)\n", ec.failed_type ? ec.failed_type->name : "unknown");
        exit(3);
    }

	pf = fopen("/home/svs_req.dat", "wb+");
	if (pf) {

		fwrite(buf, ec.encoded, 1, pf);
		fclose(pf);
		pf = NULL;
	}

	//
	rval = ber_decode(NULL, &asn_DEF_SVSRequest, &req_dec, buf, ec.encoded);
	if (rval.code == RC_OK) {

		printf("\n ----- decode successful-----\n");
		printf("version: %d\n", req_dec->version);
		printf("reqType: %d\n", req_dec->reqType);
		if (req_dec->request.present == Request_PR_exportCertReq) {

			printf("request: %s\n", req_dec->request.choice.exportCertReq.identification.buf);
		}
		printf("gmt: %s\n", req_dec->reqTime.buf);

	} else {

		printf("\n ----- decode failed ------\n");
		exit(4);
	}

	//============================================================================
	// response
	res_enc = (SVSRespond_t*)calloc(1, sizeof(SVSRespond_t));
	if (!res_enc) {

		perror("calloc failed");
		exit(5);
	}

	res_enc->version = 0;
	res_enc->respType = RespType_exportCert;

	unsigned char cert[2048];
	int cert_len = 2048;
	Certificate_t *x = NULL;

	pf = fopen("x.cer", "rb");
	//pf = fopen("cert", "rb");
	if (pf == NULL) {

		printf("fopen() failed!\n");
		exit(6);
	}
	cert_len = fread(cert, 1, 2048, pf);
	printf("cert_len = %d\n", cert_len);
	fclose(pf);
	pf = NULL;

	rval = ber_decode(NULL, &asn_DEF_Certificate, &x, cert, cert_len);
	if (rval.code != RC_OK) {

		printf("ber_decode() failed!\n");
		exit(7);
	}

	res_enc->respond.present = Respond_PR_exportCertResp;
	res_enc->respond.choice.exportCertResp.cert = x;
	res_enc->respond.choice.exportCertResp.respValue = 0;

	//
	now = time(NULL);
	cur_tm = localtime(&now);
	asn_time2GT(&res_enc->respTime, cur_tm, 1);

	len = sizeof(buf);
	ec = der_encode_to_buffer(&asn_DEF_SVSRespond, res_enc, buf, len);
    if(ec.encoded  == -1) {
        fprintf(stderr, "Could not encode SVSRespond (at %s)\n",
            ec.failed_type ? ec.failed_type->name : "unknown");
        exit(8);
    }

	pf = fopen("/home/svs_res.dat", "wb+");
	if (pf) {

		fwrite(buf, ec.encoded, 1, pf);
		fclose(pf);
		pf = NULL;
	}
	printf("******************\n");
	int ret;
	unsigned char b[2048] = "", *c = NULL;
	FILE *fp = NULL;
	fp = fopen("cert", "r");
	if (fp) {
		ret = fread(b, 1, sizeof(b), fp);
		printf("ret = %d\n", ret);
		fclose(fp);
		fp = NULL;
	}
//	c = base64_encode(b);
	if (!c) {
		printf("c is null\n");
	}
	printf("c len = %d\n", strlen(c));

	return 0;
}



int main()
{
	svsdata_test();

	return 0;
}
