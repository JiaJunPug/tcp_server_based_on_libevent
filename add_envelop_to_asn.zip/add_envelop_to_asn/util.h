#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <assert.h>

/*   鍒犻櫎宸﹁竟鐨勭┖鏍?  */
char * l_trim(char * szOutput, const char *szInput);
 
/*   鍒犻櫎鍙宠竟鐨勭┖鏍?  */
char *r_trim(char *szOutput, const char *szInput);
 
/*   鍒犻櫎涓よ竟鐨勭┖鏍?  */
char * a_trim(char * szOutput, const char * szInput);
 
 
int GetProfileString(const char *profile,  const char *KeyName, char *KeyVal );

int GetProfileInt(const char *profile, const char *KeyName, int *Keyval );
