#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <assert.h>

#define KEYVALLEN  128

char * l_trim(char * szOutput, const char *szInput)
{
	assert(szInput != NULL);
	assert(szOutput != NULL);
	assert(szOutput != szInput);
	for   (NULL; *szInput != '\0' && isspace(*szInput); ++szInput){
		;
	}
	return strcpy(szOutput, szInput);
}

/*   鍒犻櫎鍙宠竟鐨勭┖鏍?  */
char *r_trim(char *szOutput, const char *szInput)
{
    char *p = NULL;
    assert(szInput != NULL);
    assert(szOutput != NULL);
    assert(szOutput != szInput);
    strcpy(szOutput, szInput);
    for(p = szOutput + strlen(szOutput) - 1; p >= szOutput && isspace(*p); --p){
        ;
    }
    *(++p) = '\0';
    return szOutput;
}
 
/*   鍒犻櫎涓よ竟鐨勭┖鏍?  */
char * a_trim(char * szOutput, const char * szInput)
{
    char *p = NULL;
    assert(szInput != NULL);
    assert(szOutput != NULL);
    l_trim(szOutput, szInput);
    for   (p = szOutput + strlen(szOutput) - 1;p >= szOutput && isspace(*p); --p){
        ;
    }
    *(++p) = '\0';
    return szOutput;
}
 
int GetProfileString(const char *profile,  const char *KeyName, char *KeyVal )
{
    char keyname[32];
    char *buf,*c;
    char buf_i[KEYVALLEN], buf_o[KEYVALLEN];
    FILE *fp;
    int found=0; /* 1 AppName 2 KeyName */
    if( (fp=fopen( profile,"r" ))==NULL ){
        printf( "openfile [%s] error [%s]\n",profile,strerror(errno) );
        return(-1);
    }
    fseek( fp, 0, SEEK_SET );
 
    while( !feof(fp) && fgets( buf_i, KEYVALLEN, fp )!=NULL ){
        l_trim(buf_o, buf_i);
        if( strlen(buf_o) <= 0 )
            continue;
        buf = NULL;
        buf = buf_o;
 
        if( buf[0] == '#' ){
                continue;
            } else {
                //char *strchr(const char* _Str,char _Val)
                //杩斿洖棣栨鍑虹幇_Val鐨勪綅缃殑鎸囬拡锛岃繑鍥炵殑鍦板潃鏄鏌ユ壘瀛楃涓叉寚閽堝紑濮嬬殑绗竴涓笌Val鐩稿悓瀛楃鐨勬寚閽堬紝濡傛灉Str涓笉瀛樺湪Val鍒欒繑鍥濶ULL
                if( (c = (char*)strchr(buf, '=')) == NULL )
                    continue;
                memset( keyname, 0, sizeof(keyname) );
 
                sscanf( buf, "%[^=|^ |^\t]", keyname );
                if( strcmp(keyname, KeyName) == 0 ){
                    sscanf( ++c, "%[^\n]", KeyVal );
                    char *KeyVal_o = (char *)malloc(strlen(KeyVal) + 1);
                    if(KeyVal_o != NULL){
                        memset(KeyVal_o, 0, sizeof(KeyVal_o));
                        a_trim(KeyVal_o, KeyVal);
                        if(KeyVal_o && strlen(KeyVal_o) > 0)
                            strcpy(KeyVal, KeyVal_o);
                        free(KeyVal_o);
                        KeyVal_o = NULL;
                    }
                    found = 2;
                    break;
                } else {
                    continue;
                }
            }
//        }
    }
    fclose( fp );
    if( found == 2 )
        return(0);
    else
        return(-1);
}
 
int GetProfileInt(const char *profile, const char *KeyName, int *Keyval )
{
    char KeyVal[16];
    GetProfileString(profile,KeyName,KeyVal);
    *Keyval = atoi(KeyVal);
    return 0;
}
